package Gestores;

import VC.VistaComercial;
import proyecto.Comercial;
import proyecto.Venta;
import proyecto.VentaMensual;

import java.util.ArrayList;
import java.util.Calendar;

public class GestorControladorComercial {
    private VistaComercial vistaComercial;
    private Comercial comercial;

    public GestorControladorComercial(VistaComercial vistaComercial, Comercial comercial) {
        this.vistaComercial = vistaComercial;
        this.comercial = comercial;
    }

    public void addVenta() {
        String descripcion = vistaComercial.getTxtVenta();
        Calendar calendario = vistaComercial.getFecha();
        VentaMensual ventaMensual = comercial.buscarVentaMensual(calendario);
        if(ventaMensual == null){
            System.out.println("entra al null");
            ventaMensual = new VentaMensual();
            ventaMensual.setFecha(calendario);
            Venta venta = new Venta(ventaMensual.getVentas().size()+1,calendario,descripcion);
            ventaMensual.addVenta(venta);
            comercial.addVentaMensual(ventaMensual);
            System.out.println(comercial.toString());
            vistaComercial.mostrarMensaje("Se ha añadido una venta al comercial: " + comercial.getNombre() + " con la descripción: " +descripcion+ " y fecha:" + venta.imprimirFecha());
        } else{
            System.out.println("entra al otro");
            Venta venta = new Venta(ventaMensual.getVentas().size()+1,calendario,descripcion);
            ventaMensual.addVenta(venta);
            vistaComercial.mostrarMensaje("Se ha añadido una venta al comercial: " + comercial.getNombre() + " con la descripción: " +descripcion+ " y fecha:" + venta.imprimirFecha());
        }
    }

    public void mostrarVentas() {
        Calendar calendario = vistaComercial.getFecha();
        ArrayList<VentaMensual> ventasMensuales = comercial.buscarVentasAnuales(calendario);
        vistaComercial.mostrarVentasAnuales(ventasMensuales, calendario);
    }
}
