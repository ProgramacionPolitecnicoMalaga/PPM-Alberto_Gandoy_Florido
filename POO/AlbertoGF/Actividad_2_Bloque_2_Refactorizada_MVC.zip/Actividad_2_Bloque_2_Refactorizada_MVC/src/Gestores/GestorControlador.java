package Gestores;

import VC.ControladorComercial;
import VC.Vista;
import VC.VistaComercial;
import proyecto.Comercial;
import proyecto.Comerciales;

import javax.swing.*;

public class GestorControlador {
    private Vista vista;
    private Comerciales comerciales;

    public GestorControlador(Vista vista, Comerciales comerciales) {
        this.vista = vista;
        this.comerciales = comerciales;
        vista.mostrarComerciales(comerciales.getComerciales());
    }

    public void addComercial() {
        String nombre = vista.getTxtComercial();
        Comercial comercial = new Comercial(nombre);
        comerciales.addComercial(comercial);
        vista.añadirComercialBox(comercial);
        vista.mostrarMensaje("Se ha añadido correctamente el comercial: " + comercial.getNombre());
    }

    public void limpiar() {
        vista.limpiarTexto();
    }

    public void buscarComercial() {
        String nombre = vista.getTxtBuscar();
        Comercial comercial = comerciales.buscarComercial(nombre);
        vista.buscarComercial(comercial);
    }

    public void eliminarComercial() {
        String nombre = vista.getTxtEliminar();
        Comercial comercial = comerciales.buscarComercial(nombre);
        if(comercial!= null){
            comerciales.getComerciales().remove(comercial);
            vista.eliminarComercial(comercial);
            vista.mostrarMensaje("El comercial " + comercial.getNombre() + " se ha eliminado correctamente");
        }else{
            vista.mostrarMensaje("No se ha encontrado el comercial a eliminar");
        }
    }

    public void abrirComercial() {
        Comercial comercial = comerciales.buscarComercial(vista.getComboxComercial());
        crearVistaComercial(comercial);
    }

    private void crearVistaComercial(Comercial comercial){
        JFrame ventana = new JFrame(comercial.getNombre());
        VistaComercial vistaComercial = new VistaComercial(comercial);
        ControladorComercial cC = new ControladorComercial(new GestorControladorComercial(vistaComercial,comercial));
        vistaComercial.setControlador(cC);

        ventana.setDefaultCloseOperation(2);
        ventana.setContentPane(vistaComercial);

        ventana.pack();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}
