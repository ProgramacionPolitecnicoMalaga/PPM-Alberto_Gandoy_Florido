package proyecto;

public class ComercialException extends Exception {
    public ComercialException(String message) {
        super(message);
    }

    public ComercialException() {
        super();
    }
}
