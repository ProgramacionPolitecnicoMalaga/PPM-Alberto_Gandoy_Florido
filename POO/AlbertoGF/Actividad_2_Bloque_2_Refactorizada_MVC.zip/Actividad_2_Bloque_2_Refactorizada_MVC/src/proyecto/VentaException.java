package proyecto;

public class VentaException extends Exception {
    public VentaException(String message) {
        super(message);
    }

    public VentaException() {
        super();
    }
}
