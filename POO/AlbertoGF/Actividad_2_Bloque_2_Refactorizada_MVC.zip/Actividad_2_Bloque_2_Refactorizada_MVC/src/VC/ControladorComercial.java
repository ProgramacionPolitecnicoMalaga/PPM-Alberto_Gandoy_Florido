package VC;

import Gestores.GestorControlador;
import Gestores.GestorControladorComercial;
import proyecto.Comercial;
import proyecto.Venta;
import proyecto.VentaMensual;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ControladorComercial implements ActionListener {
    private GestorControladorComercial gestorControladorComercial;

    public ControladorComercial(GestorControladorComercial gestorControladorComercial){
        this.gestorControladorComercial = gestorControladorComercial;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("AñadirVenta")) {
            gestorControladorComercial.addVenta();
        }else if (e.getActionCommand().equals("Mostrar")) {
            gestorControladorComercial.mostrarVentas();
        }
    }
}
