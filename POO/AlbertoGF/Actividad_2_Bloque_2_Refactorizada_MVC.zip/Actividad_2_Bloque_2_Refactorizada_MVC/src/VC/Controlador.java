package VC;

import Gestores.GestorControlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener {
    private GestorControlador gestorVistaComerciales;

    public Controlador(GestorControlador gestorVistaComerciales) {
        this.gestorVistaComerciales = gestorVistaComerciales;

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("AñadirComercial")) {
            gestorVistaComerciales.addComercial();
        }else if (e.getActionCommand().equals("Limpiar")) {
            gestorVistaComerciales.limpiar();
        } else if (e.getActionCommand().equals("Buscar")) {
            gestorVistaComerciales.buscarComercial();
        } else if (e.getActionCommand().equals("Nuevodocumento")) {
            //generadorArchivo.generarComercialByVentaXml(comerciales, vista.getTxtGenerateFile() + "_FileMvc");
        } else if (e.getActionCommand().equals("Eliminar")) {
            gestorVistaComerciales.eliminarComercial();
        } else if (e.getActionCommand().equals("Mejor")) {

        }else if(e.getActionCommand().equals("Opciones")){
            gestorVistaComerciales.abrirComercial();
        }
    }


}
