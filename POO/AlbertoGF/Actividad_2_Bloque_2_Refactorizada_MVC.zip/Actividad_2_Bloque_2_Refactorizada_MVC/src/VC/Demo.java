package VC;
import Gestores.GestorControlador;
import LeerEscribir.ExportadorXML;
import LeerEscribir.LectorFactory;
import proyecto.Comercial;
import proyecto.Comerciales;
import proyecto.VentaMensual;

import java.awt.event.ActionListener;

public class Demo {
    public static void main(String[] args) {
     Vista vista = new Vista();
     VentaMensual vMes = new VentaMensual();
     ExportadorXML exportadorXML = new ExportadorXML();
     Comerciales comerciales = new Comerciales(LectorFactory.crearLectorXML());
     Comercial comercial = new Comercial();
     GestorControlador gestorVistaComerciales = new GestorControlador(vista,comerciales);
     ActionListener controlador = new Controlador(gestorVistaComerciales);
     vista.setControlador(controlador);
     vista.init();

    }
}
