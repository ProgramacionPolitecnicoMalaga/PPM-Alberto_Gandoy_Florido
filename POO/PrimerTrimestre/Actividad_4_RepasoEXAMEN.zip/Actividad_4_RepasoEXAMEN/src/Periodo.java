import java.util.ArrayList;

public class Periodo {

    private long tiempoInit;
    private long tiempoFin;

    public Periodo(long tiempoInit, long tiempoFin) throws TareaException {
        if (tiempoFin <= tiempoInit) {
            throw new TareaException("El tiempo de fin tiene ser mayor que el inicial");
        }else {
        this.tiempoInit = tiempoInit;
        this.tiempoFin = tiempoFin;
        }
    }

    public long getTiempoInit() {
        return tiempoInit;
    }

    public void setTiempoInit(long tiempoInit) {
        this.tiempoInit = tiempoInit;
    }

    public long getTiempoFin() {
        return tiempoFin;
    }

    public void setTiempoFin(long tiempoFin) {
        this.tiempoFin = tiempoFin;
    }

    @Override
    public String toString() {
        return "Periodo{" +
                "tiempoInit=" + tiempoInit +
                ", tiempoFin=" + tiempoFin +
                '}';
    }
}
