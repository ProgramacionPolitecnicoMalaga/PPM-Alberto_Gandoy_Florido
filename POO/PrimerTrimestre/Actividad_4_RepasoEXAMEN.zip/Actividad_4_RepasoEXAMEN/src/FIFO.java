import java.util.ArrayList;

public class FIFO implements Algoritmo {

    @Override
    public Tarea siguienteTarea(ArrayList<Tarea> tareas) {
        return tareas.get(0);
    }

    @Override
    public long determinarTiempoDeEjecucion(Tarea tarea) {
        return tarea.getDuracion();
    }
}
