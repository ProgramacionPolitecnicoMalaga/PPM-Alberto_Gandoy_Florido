import java.util.ArrayList;

public class Planificador {
    private ArrayList<Tarea> tareasEspera;
    private ArrayList<Tarea> tareasCompletadas;
    private Algoritmo algoritmo;

    public Planificador(Algoritmo algoritmo) {
        tareasCompletadas = new ArrayList<>();
        tareasEspera = new ArrayList<>();
        this.algoritmo = algoritmo;
    }

    public ArrayList<Tarea> getTareasEspera() {
        return tareasEspera;
    }

    public ArrayList<Tarea> getTareasCompletadas() {
        return tareasCompletadas;
    }


    public void ejecutarTarea() {
        Tarea tarea = algoritmo.siguienteTarea(tareasEspera);
        long tiempo = algoritmo.determinarTiempoDeEjecucion(tarea);
        if (tiempo >= tarea.getDuracion()){
            tareasEspera.remove(tarea);
            tareasCompletadas.add(tarea);
            System.out.println("Tarea terminada");
        }else{
            int pos = tareasEspera.indexOf(tarea);
            tareasEspera.get(pos).restarDuracion((int) tiempo);
            System.out.println("Se ha ejecutado durante " + tiempo + " y le falta " + tareasEspera.get(pos).getDuracion());
            System.out.println("--------------------------------------------------------------");
        }
        System.out.println(tiempo);
    }

    public void ejecutarTodasLasTareas(){
        while (!tareasEspera.isEmpty()){
            ejecutarTarea();
        }
    }

    public void addTarea(Tarea tarea) {
        tareasEspera.add(tarea);
    }
}
