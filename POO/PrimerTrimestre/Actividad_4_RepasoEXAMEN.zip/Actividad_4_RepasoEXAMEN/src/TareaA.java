public class TareaA extends Tarea {
    public TareaA() {
        super(1200, 1, (int)Math.random());
    }
}
