public class TareaException extends Exception{
    public TareaException() {
        super();
    }

    public TareaException(String message) {
        super(message);
    }
}
