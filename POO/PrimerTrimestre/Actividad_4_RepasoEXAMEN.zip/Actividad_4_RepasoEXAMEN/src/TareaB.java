public class TareaB extends Tarea{

    public TareaB() {
        super(600, 2, (int)Math.random());
    }
}
