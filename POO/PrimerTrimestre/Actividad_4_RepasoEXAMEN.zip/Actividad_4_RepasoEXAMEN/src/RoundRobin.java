import java.util.ArrayList;

public class RoundRobin implements Algoritmo {
    private int quantum;

    public RoundRobin(int quantum) {
        this.quantum = quantum;
    }

    public void setQuantum(int quantum) {
        this.quantum = quantum;
    }

    public int getQuantum() {
        return quantum;
    }

    @Override
    public Tarea siguienteTarea(ArrayList<Tarea> tareas) {
        Tarea guardada = tareas.remove(0);
        tareas.add(guardada);
        return guardada;
    }

    @Override
    public long determinarTiempoDeEjecucion(Tarea tarea) {//? es como if, es decir, que pregunta y si no escoge quantum(: parecido que en el foreach "NOTAS MENTALES")
        return quantum > tarea.getDuracion() ? tarea.getDuracion() : quantum;
    }
}
