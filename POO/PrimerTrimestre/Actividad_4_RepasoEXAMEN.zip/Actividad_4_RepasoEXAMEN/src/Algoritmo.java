import java.util.ArrayList;

public interface Algoritmo {
    Tarea siguienteTarea(ArrayList<Tarea> tareas);
    long determinarTiempoDeEjecucion(Tarea tarea);
}
