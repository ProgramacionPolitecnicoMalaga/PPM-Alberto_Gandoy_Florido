import java.util.Comparator;

public class ComparatorSJF implements Comparator<Tarea> {
    @Override
    public int compare(Tarea o1, Tarea o2) {
        return o1.getDuracion() - o2.getDuracion();
    }
}
