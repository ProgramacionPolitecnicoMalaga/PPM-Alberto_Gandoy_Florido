public class Main {
    public static void main(String[] args) {
        Algoritmo sjf = new SJF();
        Algoritmo roundRobin = new RoundRobin(300);
        Algoritmo fifo = new FIFO();
        Planificador planificador = new Planificador(roundRobin);
        planificador.addTarea(new TareaA());
        planificador.addTarea(new TareaB());
        planificador.addTarea(new TareaB());
        planificador.addTarea(new TareaC());

        planificador.ejecutarTodasLasTareas();
    }
}
