public class TareaC extends Tarea {

    public TareaC() {
        super(1800, 3, (int)Math.random());
    }
}
