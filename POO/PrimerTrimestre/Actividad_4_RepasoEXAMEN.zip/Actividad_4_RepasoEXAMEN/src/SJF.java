import java.util.ArrayList;
import java.util.Collections;

public class SJF implements Algoritmo {

    @Override
    public Tarea siguienteTarea(ArrayList<Tarea> tareas) {
        Collections.sort(tareas);
        return tareas.get(0);
    }

    @Override
    public long determinarTiempoDeEjecucion(Tarea tarea) {
        return tarea.getDuracion();
    }

}
