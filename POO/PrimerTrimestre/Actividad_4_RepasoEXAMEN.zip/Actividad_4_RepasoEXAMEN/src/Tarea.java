import java.util.ArrayList;

public class Tarea implements Comparable<Tarea>{

    private int duracion;
    private int prioridad;
    private int id;
    private boolean ejecucion;
    private ArrayList<Periodo> periodos;

    public Tarea(int duracion, int prioridad, int id){
        if(duracion <= 0){
            try {
                throw new TareaException("Una tarea no puede tener una duración negativa");
            } catch (TareaException e) {
                e.printStackTrace();
            }
        }else{
            this.duracion = duracion;
            this.prioridad = prioridad;
            this.id = id;
            this.ejecucion = false;
            periodos = new ArrayList<>();
        }

    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    public void restarDuracion(int duracion){this.duracion -= duracion;}

    public int getPrioridad() {
        return prioridad;
    }

    public boolean isEjecucion() {
        return ejecucion;
    }

    public void setEjecucion(boolean ejecucion) {
        this.ejecucion = ejecucion;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void addPeriodo(Periodo periodo) {
        periodos.add(periodo);
    }
    @Override
    public String toString() {
        return "Tarea{" +
                "duracion=" + duracion +
                ", prioridad=" + prioridad +
                ", id=" + id +
                '}';
    }

    @Override
    public int compareTo(Tarea o) {
        return this.getDuracion() - o.getDuracion();
    }
}


