public class ExceptionCalculos extends Exception {
    public ExceptionCalculos(String mensaje) {
        super(mensaje);
    }
}
